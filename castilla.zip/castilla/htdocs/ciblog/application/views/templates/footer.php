		</div>
		<script>
                CKEDITOR.replace( 'editor1' );
            </script>
	</body>
</html>