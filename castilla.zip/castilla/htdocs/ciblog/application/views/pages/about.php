<h2><?= $title ?></h2>
<p>About blog version 2.1.3</p>