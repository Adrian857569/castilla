<h2><?= $title ?></h2>
<p>This is home my homie.</p>